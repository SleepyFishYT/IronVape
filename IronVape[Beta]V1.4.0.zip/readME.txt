
Just dragg the luma folder in ur Root of 3DS SD-Card

---------------------------------------------
- Dont try to Steal codes BTW thats Illigal -
---------------------------------------------
YouTube : https://youtu.be/Ar55zce7OY8
Discord : https://discord.gg/KpgaCsZxSN
---------------------------------------------
Creator:
SleepyFish
---------------------------------------------
Helpers:
FooFoo_The_Guy: Functions
Lukas         : Functions
PabloMK7      : Functions
MikeWii       : Research, Codes
---------------------------------------------

Just dragg the luma folder in ur Root of 3DS SD-Card

